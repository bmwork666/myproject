// src/tagList.js
const tagList = [
  "Var.ML.shift",
  "Var.ML.count",
  "Var.ML.PetrolAT",
  "Var.ML.PetrolMT",
  "Var.ML.DieselAT",
  "Var.ML.DieselMT",

  "Var.FM.shift",
  "Var.FM.count",

  "Var.RM.shift",
  "Var.RM.count",
  "Var.RM.PetrolAT",
  "Var.RM.PetrolMT",
  "Var.RM.DieselAT",
  "Var.RM.DieselMT",
];

export default tagList;
