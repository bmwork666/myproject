import React, { useRef, useState, useEffect } from "react";
import Slider from "react-slick";
import axios from "axios";

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "bootstrap/dist/css/bootstrap.min.css";

import Ml from "./components/Ml";
import Fm from "./components/Fm";
import Rm from "./components/Rm";
import Test from "./components/Test";

import tagList from "./tagList";

function App() {
  const sliderRef = useRef(null);
  const [autoPlay, setAutoPlay] = useState(true);

  // DATA STATES
  const [mlData, setMlData] = useState({});
  const [fmData, setFmData] = useState({});
  const [rmData, setRmData] = useState({});

  // FETCH FROM PLC API
  useEffect(() => {
    async function loadData() {
      try {
        const res = await axios.post(
          "http://localhost:9010/RTDB/WebAPI/GetTags",
          JSON.stringify(tagList),
          { headers: { "Content-Type": "application/json" } }
        );

        if (!res.data.message) return;

        const raw = res.data.message;

        const obj = {};
        raw.forEach((item) => {
          obj[item.Key] = item.Value;
        });

        setMlData({
          shift: obj["Var.ML.shift"],
          count: obj["Var.ML.count"],
          PetrolAT: obj["Var.ML.PetrolAT"],
          PetrolMT: obj["Var.ML.PetrolMT"],
          DieselAT: obj["Var.ML.DieselAT"],
          DieselMT: obj["Var.ML.DieselMT"],
        });

        setFmData({
          shift: obj["Var.FM.shift"],
          count: obj["Var.FM.count"],
        });

        setRmData({
          shift: obj["Var.RM.shift"],
          count: obj["Var.RM.count"],
          PetrolAT: obj["Var.RM.PetrolAT"],
          PetrolMT: obj["Var.RM.PetrolMT"],
          DieselAT: obj["Var.RM.DieselAT"],
          DieselMT: obj["Var.RM.DieselMT"],
        });

      } catch (error) {
        console.error("API ERROR:", error);
      }
    }

    loadData();
    const interval = setInterval(loadData, 2000);
    return () => clearInterval(interval);

  }, []);

  // SLIDER SETTINGS
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: autoPlay,
    autoplaySpeed: 5000,
    arrows: false,
  };

  return (
    <div className="container-fluid p-0">

      <Slider ref={sliderRef} {...settings}>

        {/* ML SLIDE */}
        <div className="container-fluid d-flex align-items-center justify-content-center" style={{ height: "100vh" }}>
          <div className="row w-100 g-4 px-3">
            <div className="col-12 col-sm-10 col-md-8 col-lg-6 mx-auto">
              <Ml data={mlData} />
            </div>
          </div>
        </div>

        {/* FM SLIDE */}
        <div className="container-fluid d-flex align-items-center justify-content-center" style={{ height: "100vh" }}>
          <div className="row w-100 g-4 px-3">
            <div className="col-12 col-sm-10 col-md-8 col-lg-6 mx-auto">
              <Fm data={fmData} />
            </div>
          </div>
        </div>

        {/* RM SLIDE */}
        <div className="container-fluid d-flex align-items-center justify-content-center" style={{ height: "100vh" }}>
          <div className="row w-100 g-4 px-3">
            <div className="col-12 col-sm-10 col-md-8 col-lg-6 mx-auto">
              <Rm data={rmData} />
            </div>
          </div>
        </div>

        {/* TEST SLIDE */}
        <div className="container-fluid d-flex align-items-center justify-content-center" style={{ height: "100vh" }}>
          <div className="row w-100 g-4 px-3">
            <div className="col-12 col-sm-10 col-md-8 col-lg-6 mx-auto">
              <Test />
            </div>
          </div>
        </div>

      </Slider>

      {/* FOOTER BUTTONS */}
      <div className="text-center p-3 bg-light border-top">
        <button
          className="btn btn-sm btn-primary mx-2"
          onClick={() => {
            sliderRef.current.slickPrev();
            if (autoPlay) sliderRef.current.slickPlay();
          }}
        >
          ⬅ Prev
        </button>

        <button
          className={`btn btn-sm mx-2 ${autoPlay ? "btn-danger" : "btn-success"}`}
          onClick={() => {
            setAutoPlay(!autoPlay);
            if (!autoPlay) sliderRef.current.slickPlay();
            else sliderRef.current.slickPause();
          }}
        >
          {autoPlay ? "Stop Auto Slide" : "Start Auto Slide"}
        </button>

        <button
          className="btn btn-sm btn-primary mx-2"
          onClick={() => {
            sliderRef.current.slickNext();
            if (autoPlay) sliderRef.current.slickPlay();
          }}
        >
          Next ➡
        </button>
      </div>
    </div>
  );
}

export default App;
