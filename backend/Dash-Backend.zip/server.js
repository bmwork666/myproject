const express = require("express");
const cors = require("cors");
const readTags = require("./api/readTags");

const app = express();
app.use(cors());
app.use(express.json());

// Read ALL ML, FM, RM tags
app.get("/read-nodedata", async (req, res) => {

    const tags = [
        // ML
        "Var.ML.shift",
        "Var.ML.count",
        "Var.ML.PetrolAT",
        "Var.ML.PetrolMT",
        "Var.ML.DieselAT",
        "Var.ML.DieselMT",

        // FM
        "Var.FM.shift",
        "Var.FM.count",

        // RM
        "Var.RM.shift",
        "Var.RM.count",
        "Var.RM.PetrolAT",
        "Var.RM.PetrolMT",
        "Var.RM.DieselAT",
        "Var.RM.DieselMT"
    ];

    try {
        const data = await readTags(tags);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: "Failed to read tags", detail: error.message });
    }
});

app.listen(4000, () => {
    console.log("Backend running on port 4000");
});
